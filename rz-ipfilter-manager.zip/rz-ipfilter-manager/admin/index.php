<?php 
// Silence is golden
?>